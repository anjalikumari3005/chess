az ml computetarget create aks -n myaks
