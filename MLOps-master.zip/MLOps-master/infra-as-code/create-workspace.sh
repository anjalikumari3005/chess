az group create -n myresourcegroup -l westus2
az ml workspace create -w myworkspace -g myresourcegroup
