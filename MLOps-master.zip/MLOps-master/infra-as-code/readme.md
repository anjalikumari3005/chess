# Infrastructure as Code
This folder contains examples for how to bootstrap your machine learning workflow. 
ARM templates & Azure ML CLI commands can easily be used to bootstrap and provision workspaces for your data scientists prior to enabling them to begin data preparation & model training.
