az ml datastore attach-blob -n samplemobilenetimages -c sampleimagescontainer -a sampleimagesaccount
