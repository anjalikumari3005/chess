# flake8: noqa

from pandas.core.reshape.concat import concat
from pandas.core.reshape.melt import melt, lreshape, wide_to_long
from pandas.core.reshape.reshape import pivot_simple as pivot, get_dummies
from pandas.core.reshape.merge import merge, merge_ordered, merge_asof
from pandas.core.reshape.pivot import pivot_table, crosstab
from pandas.core.reshape.tile import cut, qcut
