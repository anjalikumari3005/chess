.. role:: hidden
    :class: hidden-section

algorithms.bit
=================
